import pika
import json
from envioemail import enviaremail

connection = pika.BlockingConnection(

    pika.ConnectionParameters('localhost')

)

# Connect and block other rabbit
channel = connection.channel()

# Declare queue's name
channel.queue_declare(queue="importers")


# Declare importers
def importers(ch, method, properties, body):
    j = json.loads(body)
    print(j)
    enviaremail(j['subject'], j['destine'], j['from'], j['cc'], j['body'])

   # envioemail.index()
    # ACK si esta activo
    # ch.basic_ack(delivery_tag=method.delivery_tag)

    # CON ACK FALSE
channel.basic_consume(importers, queue="importers", no_ack=True)


print("Worker Start")



channel.start_consuming()
